# Injury Tab — Starter Kit

A drop-in "Injury" tab for player-profile pages: durability grade, a
season-by-season availability timeline, a body map, a heuristic risk breakdown,
and a filterable full injury log. The architecture is a 6-layer pipeline —
**scrape → normalize → persist (read-through cache) → serve → fetch → derive →
render** — and the whole UI depends only on one normalized shape
(`PlayerInjuryHistory`). Swap your data source and you rewrite exactly one file.

## Files

```
injury-kit/
├── server/
│   ├── injurySource.ts     ← THE ONLY source-specific file. Scrape/fetch + normalize to PlayerInjuryHistory.
│   ├── injuryStore.ts      ← read-through cache: freshness window, single-flight, lazy, last-known-good.
│   └── injuryRoute.ts      ← Express route factory.
├── client/
│   ├── injuryApi.ts        ← the data contract (types) + fetch function.
│   ├── injuryDerivations.ts← pure helpers: summary, risk breakdown, narratives, region classify.
│   ├── InjuryAvailabilityTimeline.tsx ← the week-grid timeline (also exports the severity model).
│   ├── InjuryBodyMap.tsx   ← the SVG body silhouette with region markers.
│   ├── InjuryTab.tsx       ← composes the four cards into the tab.
│   └── ui.tsx              ← minimal Card / SkeletonLines / ComingSoon / SectionTitle / Tooltip / cn.
└── data/
    └── sample-injury-history.json ← a PlayerInjuryHistory payload for offline rendering.
```

## Dependencies

- **Server:** Node 18+ (global `fetch`), Express. The store has **no DB
  dependency** — it ships an in-memory implementation; plug in your DB via the
  `InjuryStorage` interface (a Drizzle sketch is in `injuryStore.ts`).
- **Client:** React 18+, TypeScript, `lucide-react`, Tailwind CSS. The kit uses
  semantic Tailwind tokens (`bg-card`, `text-foreground`, `border-border`,
  `text-muted-foreground`, `bg-popover`, `dark-any:*`). Add those tokens or
  replace with literal classes. **No shadcn/Radix required** — `ui.tsx` includes
  a lightweight CSS tooltip (swap in shadcn's Radix tooltip for collision-aware
  positioning if you want it).

## The data contract (define first)

Everything keys off this. The same type lives in `server/injurySource.ts` and
`client/injuryApi.ts` — keep them identical.

```ts
PlayerInjuryHistory {
  grade: string | null;       // "A+"
  score: number | null;       // 0–100, LOWER = more risk
  gradeColor: string | null;  // hex for the grade box
  nfl:    NflInjuryEntry[];    // newest first: season, week, type, bodyPart, side, severity, gamesMissed, description
  college: CollegeInjuryEntry[]; // year, significance, description
}
```

## Server wiring

```ts
import express from "express";
import { createInjuryService, createInMemoryStorage } from "./server/injuryStore";
import { registerInjuryRoute } from "./server/injuryRoute";

const app = express();
const injuries = createInjuryService(createInMemoryStorage()); // swap storage for your DB
registerInjuryRoute(app, injuries.getPlayerInjuryHistory);
// → GET /api/players/:playerId/injuries?name=<displayName>  ⇒  { playerId, injuries }
```

## Client wiring (in your player page)

```tsx
import { fetchPlayerInjuryHistory, type PlayerInjuryHistory } from "./client/injuryApi";
import { InjuryTab } from "./client/InjuryTab";

const [injury, setInjury] = useState<PlayerInjuryHistory | null>(null);
const [loading, setLoading] = useState(false);
const [error, setError] = useState(false);

// Lazy-load when the tab opens (guard with a ref so it fires once per player).
useEffect(() => {
  if (tab !== "injury" || !playerId) return;
  setLoading(true); setError(false);
  fetchPlayerInjuryHistory(playerId, playerName)
    .then(setInjury).catch(() => setError(true)).finally(() => setLoading(false));
}, [tab, playerId, playerName]);

{tab === "injury" && (
  <InjuryTab
    injury={injury}
    loading={loading}
    error={error}
    playerName={playerName}
    knownSeasons={knownSeasons}     // seasons the player played → injury-free years show "Full season"
    weeklyPlayed={weeklyPlayed}     // optional: { [season]: number[] } of real weeks played
  />
)}
```

### The `weeklyPlayed` accuracy step (optional but recommended)

The injury feed only *estimates* missed weeks. If you can fetch real weekly game
logs, pass `weeklyPlayed` and the timeline treats it as authoritative — every
not-played week is marked missed, injury severity is attributed onto those
weeks, and the leftover gap is detected as the bye. Build it with a second
parallel fetch keyed on player+seasons:

```ts
// for each relevant season, fetch game logs → keep only weeks the player actually
// recorded production (a rostered-but-inactive week returns a row too) → Set<week>
weeklyPlayed[season] = playedWeeks; // { 2024: [1,2,3,5,6, ...] }
```

Without it, the timeline falls back to the injury-only estimate — still works.

## Porting checklist

1. **`injurySource.ts` is the only source-specific file.** Replace the scrape
   with your provider's API call; keep `normalize()` (remap fields) and the
   return type. Keep the **`null`-on-any-failure** contract — never throw.
2. **Single-flight + last-known-good** in the store are load-bearing. Don't drop
   them: they prevent scrape stampedes and keep a source outage from blanking
   the tab.
3. **Severity is derived, not raw.** `getDisplaySeverity` adds `played` and
   `season-ending` tiers from games-missed + keywords. Tune
   `SEASON_ENDING_KEYWORDS` and the `>= 8 games` threshold for your sport.
4. **Region keyword maps** appear in two places — `injuryDerivations.ts`
   (summary/risk regions) and `InjuryBodyMap.tsx` (silhouette coordinates).
   Extend both if your data uses body-part terms not covered.
5. **Empty ≠ error.** A 200 with `{ injuries: null }` is the empty state; a
   thrown fetch is the error state. The tab renders them differently.

## Smoke test

Feed `data/sample-injury-history.json` straight into `<InjuryTab injury={...}
loading={false} error={false} playerName="Test Player" knownSeasons={[2021,2022,2023,2024]} />`.
You should see: a `C+` / 64 grade box reading "Moderate Injury Risk"; a timeline
with 2022 showing the ACL tear as season-ending (red) and 2024 showing a 3-game
hamstring miss; a body map with knee/hamstring/head/ankle/shoulder markers; and
a Full Injury Log that filters and groups by season. Swapping `score` to `35`
should flip the headline to "High Injury Risk".
```
